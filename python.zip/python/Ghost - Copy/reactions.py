

def on_reaction_add(reaction, user):
    # Steals your reaction by removing the original and adding it's own
    if not user.bot and reaction.message.content == reaction.message.content:
        return reaction.message.add_reaction(reaction.emoji)