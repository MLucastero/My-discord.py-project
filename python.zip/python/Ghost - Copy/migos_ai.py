
import discord
import random
import os
import json
client = discord.Client()
token = 'OTQyNDExNzE2OTE3MDgwMTE0.YgkHTg.9E3HyRTWSuljAnJyKxtVGkQF87g'
os.chdir("C:\\Users\\Administrator\\PycharmProjects\\pythonProject\\Ghost")
@client.event
async def on_ready():
   
    print('waking up {0.user}'.format(client))

@client.event
async def on_message(message):
    username = str(message.author).split('#')[0]
    use_message = str(message.content)
    channel = str(message.channel.name)
    guild = str(message.guild.name)
    print(f'{username}: {use_message} ({channel}) ({guild})')
    
    if message.author == client.user:
        return
    if message.channel.name == message.channel.name:
        if use_message.lower()  == '<@!945327140730175569> help':
            await message.channel.send('My prefix is `$ sudo `')
            return
        if 'azuki' in use_message.lower():
            await message.channel.send('?')
            return
        
@client.event
async def on_reaction_add(reaction, user):
    # Steals your reaction by removing the original and adding it's own
    if reaction.message.content == reaction.message.content:
        await reaction.message.add_reaction(reaction.emoji)

client.run(token)